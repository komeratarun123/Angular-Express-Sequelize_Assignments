// const express = require("express");
// const Sequelize= require("sequelize");
// const app =express();
// const db1=require("./db.config");
// var sequelize = new Sequelize(db1.DB,db1.USER,db1.PASSWORD,{
//     host:db1.HOST,
//     dialect:db1.dialect,
//     pool:{
//         min:db1.pool.min,
//         max:db1.pool.max,
//         acquire:db1.pool.acquire,
//         idle:db1.pool.idle
//     }
// });

// let Student1=sequelize.define('Student1',{
//      emp_id:{
//        primaryKey:true,
//        type:Sequelize.INTEGER
//      },
//    name:Sequelize.STRING,
//    dept:Sequelize.STRING,
//    designation:Sequelize.STRING
// },{
//    timestamps:false,
//    freezeTableName:true
// });
// // Student1.sync().then(()=>{
// //     console.log("Table is created successfully");
// // }).catch((err)=>{
// //         console.log("Error occurred"+err)
// // })


// app.get("/",(req,res)=>{
//     console.log("This is a get request");
//     res.send("get request is successful send");
// })

// app.get("/getAllStudent",(req,res)=>{
//     Student1.findAll({raw:true}).then(data=>{
//         console.log(data);
//         res.status(200).send(data);
//     }).catch(err =>{
//         console.log("There is an error in gettting data ");
//         res.status(400).send(err);
//     })
// })
// app.get("/getStudentById/:id",(req,res)=>{
//     var id=req.params.id;
//     console.log("Given is is :"+id);
//     Student1.findByPk(id,{raw:true}).then(data=>{
//         console.log(data);
//         res.status(200).send(data)
//     }).catch(err =>{
//         console.error("There is an error in the code");
//         res.status(400).send(err);
//     })
// })
// app.use(express.json())
// app.post("/insertStudent",(req,res)=>{

//     var emp_id=req.body.emp_id;
//     var name =req.body.name;
//     var dept =req.body.dept;
//     var designation=req.body.designation;
  
//     var empObj =Student1.build({emp_id:emp_id,name:name,dept:dept,designation:designation});
//     empObj.save().then(data=>{
//         var strMsg="Record inserted Successfully";
//         res.status(201).send(strMsg);
//     }).catch(err=>{
//         console.error("Error is"+err);
//         res.status(400).send(err);
//     })
// })
// app.put("/updateStudent",(req,res)=>{
//     var emp_id=req.body.emp_id;
//     var name=req.body.name;
//     var dept=req.body.dept;
//     var designation=req.body.designation;

//    Student1.update(
//        {name:name,dept:dept,designation:designation},
//        {where:{emp_id:emp_id}}
//    ).then(data=>{
//        console.log(data);
//        var str ="Record updated successfully";
//        res.status(201).send(str);
//    }).catch(err =>{
//        console.log("there is a error in updating the table");
//        res.status(400).send(err);
//    })
    
// });
// app.delete("/deleteStudentById/:id",(req,res)=>{
//     var id =req.params.id;
//     console.log("Id recieved is"+id);
//     Student1.destroy({where:{emp_id:id}
//     }).then(data =>{
//     var str="Record deleted successfully";
//     res.status(200).send(str);
// }).catch(err=>{
//       console.log("There is error in the delete code");
//       res.status(400).send (err);
//   })

// })

// app.listen(8000,(req,res)=>{
//     console.log("Server is listening");
    
// })